Welcome to PHD2 Release Version v2.2.0

PHD2 is the next generation of Craig Stark's original PHD Guiding application, now restructured, enhanced, and supported by an open-source community of volunteers.  PHD2's new built-in help file is an excellent way to get started using the program, regardless of whether you've had previous experience with the original PHD. 

Some of the major enhancements with this release include the following: 

    Multi-threading to improve responsiveness in the user interface
    Support for adaptive optics devices
    More extensive visualization tools 
        Display of guide commands when they are issued
        Display of errors and statistics in units of arc-seconds or pixels
        "Target/bulls-eye" display 
        Customizable color schemes
        Display of adaptive optics corrections including mount "bumps"
        Dockable/moveable windows
    Enhanced support for ASCOM mounts 
        Declination compensation 
        Automatic detection and adjustment for pier flip with German equatorial mounts
    Improved calibration 
        Calculator for determining optimal calibration guide pulse 
        Automatic "save" and optional reload of calibration data
        Optional fast re-centering during calibration 
    Streamlined device connection 
        Single form with "connect all" option for all devices
        Equipment profiles for managing multiple guiding configurations 
        Direct connection to ASCOM devices without reliance on ASCOM "chooser"          
    Better support for third-party application integration including Sequence Guider Pro
        Standardized server interface 
        Event monitoring interface
    Improved dark frame handling 
        Automatic exposure-time "matching" 
        Support for "dark libraries" across multiple program executions
    Wider set of choices for declination guide algorithms
    Expanded features for"manual" guiding and trouble-shooting
        User-defined pulse length 
        Manual dithering
    More sophisticated mount/camera simulators for "daylight" experimentation and familiarization
    Polar alignment function
    Support for bookmarks to fine-tune guide star location
    Improved screen brightness adjustment
    Extended logging support including user-defined directory locations
    Localization for French-speaking users

Further information on program content and changes from the earlier beta releases can be obtained on the <openphdguiding> web site.

For questions about using the application and general troublehooting, please post on
the stark-labs-astronomy-software Yahoo! group,

   http://groups.yahoo.com/neo/groups/stark-labs-astronomy-software/

For bug reports, feature requests, and questions about PHD2 development, please join the
discussion on the Open PHD Guiding google group,

   https://groups.google.com/forum/#!forum/open-phd-guiding

Thanks,

The PHD2 team

