/*****************************************************************************************
NAME
 States

DESCRIPTION
 Camera states

COPYRIGHT (C)
 QSI (Quantum Scientific Imaging) 2005-2006

REVISION HISTORY
 MWB 04.16.06 Original Version
*****************************************************************************************/

#pragma once
//
//QSI uses MaxIm definitions for the following
//
// Moved to QSI_GLobal.h
