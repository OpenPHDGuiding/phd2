/*****************************************************************************************
NAME
 USBWrapper

DESCRIPTION
 USB Wrapper

COPYRIGHT (C)
 QSI (Quantum Scientific Imaging) 2005-2009

REVISION HISTORY
 MWB 04.28.06 Original Version
******************************************************************************************/

// Obsolete
