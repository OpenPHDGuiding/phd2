/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * qsilib
 * Copyright (C) Quantum Scientific Imaging, Inc. 2013 <dchallis@qsimaging.com>
 * 
 */

#include "IHostIO.h"

IHostIO::IHostIO(void)
{
}


IHostIO::~IHostIO(void)
{
}

