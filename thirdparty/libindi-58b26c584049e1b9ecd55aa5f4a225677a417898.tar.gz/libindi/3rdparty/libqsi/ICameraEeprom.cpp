/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * qsilib
 * Copyright (C) QSI 2012 <dchallis@qsimaging.com>
 * 
 */

#include "ICameraEeprom.h"

ICameraEeprom::~ICameraEeprom() {};
