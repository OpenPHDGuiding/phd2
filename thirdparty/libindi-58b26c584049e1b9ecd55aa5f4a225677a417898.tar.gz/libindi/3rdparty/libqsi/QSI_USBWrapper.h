/*****************************************************************************************
NAME
 USBWrapper

DESCRIPTION
 USB Wrapper

COPYRIGHT (C)
 QSI (Quantum Scientific Imaging) 2005-2012

REVISION HISTORY
 MWB 04.28.06 Original Version
 *****************************************************************************************/ 

#pragma once
// Obsolete
