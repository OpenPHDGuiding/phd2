/* Set INDI Library version */
#define INDI_VERSION 2.0.3

/* Define INDI Data Dir */
#define DATA_INSTALL_DIR "C:/CraftRoot/share/indi/"
