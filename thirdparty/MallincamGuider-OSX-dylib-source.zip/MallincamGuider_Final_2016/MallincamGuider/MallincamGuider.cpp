//
//  MallincamGuider.m
//  MallincamGuider
//
//  Created by pufahl on 5/6/16.
//  Copyright (c) 2016 rD. All rights reserved.
//

#include "MallincamGuider.h"
#import <CoreFoundation/CoreFoundation.h>

#include <dlfcn.h>
#include "toupcam.h"

#ifdef _WIN32
    HToupCam (*_myOpenFunc)(const wchar_t* id);
#else
    HToupCam (*_myOpenFunc)(const char* id);
#endif
unsigned (*_myEnumFunc)(ToupcamInst pti[MALLINCAM_MAX]);
MRESULT (*_myPullFunc)(HToupCam h, PTOUPCAM_EVENT_CALLBACK pEventCallback, void* pCallbackContext);
MRESULT (*_myPushFunc)(HToupCam h, PTOUPCAM_DATA_CALLBACK pDataCallback, void* pCallbackContext);
MRESULT (*_myPullImageFunc)(HToupCam h, void* pImageData, int bits, unsigned* pnWidth, unsigned* pnHeight);
MRESULT (*_myStopFunc)(HToupCam h);

MRESULT (*_myGetResolutionFunc)(HToupCam h, unsigned nResolutionIndex, int* pWidth, int* pHeight);

MRESULT (*_myST4GuideFunc)(HToupCam h, unsigned nDirect, unsigned nDuration);


MRESULT (*_myGetGainRangeFunc)(HToupCam h, unsigned short* nMin, unsigned short* nMax, unsigned short* nDef);

MRESULT (*_myGetGainFunc)(HToupCam h, unsigned short* AGain);

MRESULT (*_myPutGainFunc)(HToupCam h, unsigned short AGain);

MRESULT (*_myGetExpoTimeFunc)(HToupCam h, unsigned* Time);
MRESULT (*_myPutExpoTimeFunc)(HToupCam h, unsigned Time);

/* Constructor */
MallincamGuider::MallincamGuider()
{
 
/*tried and failed
 void* lib_handle = dlopen("libmallincam.dylib", RTLD_LOCAL);
 lib_handle = dlopen("@executable_path/libmallincam.dylib", RTLD_LOCAL);
 void* lib_handle = dlopen("toupcam_osx/procom/libmallincam.dylib", RTLD_LOCAL);

 
*/
    
  void* lib_handle = dlopen("@executable_path/../Frameworks/MallincamGuider.framework/Versions/A/Resources/libmallincam.dylib", RTLD_LOCAL);
    
    if (!lib_handle)
    {
        printf("[%s] Unable to get mallincam dylib: %s\n", __FILE__, dlerror());
        exit(EXIT_FAILURE);

    }
  
    if (lib_handle)
    {
        *(void **) (&_myOpenFunc) = dlsym(lib_handle, "Toupcam_Open");
        //        _myOpenFunc= (void(*)(char*))dlsym(lib_handle, "Toupcam_Open");
        
        if (_myOpenFunc == NULL)
        {
            printf("[%s] Unable to get _myOpenFunc: %s\n", __FILE__, dlerror());
            exit(EXIT_FAILURE);
        }
        
//        toupcam_ports(unsigned) Toupcam_Enum(ToupcamInst pti[TOUPCAM_MAX]);
        *(void **) (&_myEnumFunc) = dlsym(lib_handle, "Toupcam_Enum");
        
        if (_myEnumFunc == NULL)
        {
            printf("[%s] Unable to get _myEnumFunc: %s\n", __FILE__, dlerror());
            exit(EXIT_FAILURE);
        }

        *(void **) (&_myPullFunc) = dlsym(lib_handle, "Toupcam_StartPullModeWithCallback");
        
        if (_myPullFunc == NULL)
        {
            printf("[%s] Unable to get _myPullFunc: %s\n", __FILE__, dlerror());
            exit(EXIT_FAILURE);
        }

        *(void **) (&_myPushFunc) = dlsym(lib_handle, "Toupcam_StartPushMode");
        
        if (_myPushFunc == NULL)
        {
            printf("[%s] Unable to get _myPushFunc: %s\n", __FILE__, dlerror());
            exit(EXIT_FAILURE);
        }
        
        *(void **) (&_myPullImageFunc) = dlsym(lib_handle, "Toupcam_PullImage");
        if (_myPullImageFunc == NULL)
        {
            printf("[%s] Unable to get _myPullImageFunc: %s\n", __FILE__, dlerror());
            exit(EXIT_FAILURE);
        }
        
        *(void **) (&_myStopFunc) = dlsym(lib_handle, "Toupcam_Stop");
        if (_myStopFunc == NULL)
        {
            printf("[%s] Unable to get _myStopFunc: %s\n", __FILE__, dlerror());
            exit(EXIT_FAILURE);
        }
        
        *(void **) (&_myGetResolutionFunc) = dlsym(lib_handle, "Toupcam_get_Resolution");
        if (_myGetResolutionFunc == NULL)
        {
            printf("[%s] Unable to get _myGetResolutionFunc: %s\n", __FILE__, dlerror());
            exit(EXIT_FAILURE);
        }

        *(void **) (&_myST4GuideFunc) = dlsym(lib_handle, "Toupcam_ST4PlusGuide");
        if (_myST4GuideFunc == NULL)
        {
            printf("[%s] Unable to get _myST4GuideFunc: %s\n", __FILE__, dlerror());
            exit(EXIT_FAILURE);
        }
        
        *(void **) (&_myGetGainRangeFunc) = dlsym(lib_handle, "Toupcam_get_ExpoAGainRange");
        if (_myGetGainRangeFunc == NULL)
        {
            printf("[%s] Unable to get _myGetGainRangeFunc: %s\n", __FILE__, dlerror());
            exit(EXIT_FAILURE);
        }
        
        *(void **) (&_myGetGainFunc) = dlsym(lib_handle, "Toupcam_get_ExpoAGain");
        if (_myGetGainFunc == NULL)
        {
            printf("[%s] Unable to get _myGetGainFunc: %s\n", __FILE__, dlerror());
            exit(EXIT_FAILURE);
        }
        
        *(void **) (&_myPutGainFunc) = dlsym(lib_handle, "Toupcam_put_ExpoAGain");
        if (_myPutGainFunc == NULL)
        {
            printf("[%s] Unable to get _myPutGainFunc: %s\n", __FILE__, dlerror());
            exit(EXIT_FAILURE);
        }

        *(void **) (&_myGetExpoTimeFunc) = dlsym(lib_handle, "Toupcam_get_ExpoTime");
        if (_myGetExpoTimeFunc == NULL)
        {
            printf("[%s] Unable to get _myGetExpoTimeFunc: %s\n", __FILE__, dlerror());
            exit(EXIT_FAILURE);
        }

        *(void **) (&_myPutExpoTimeFunc) = dlsym(lib_handle, "Toupcam_put_ExpoTime");
        if (_myPutExpoTimeFunc == NULL)
        {
            printf("[%s] Unable to get _myPutGainFunc: %s\n", __FILE__, dlerror());
            exit(EXIT_FAILURE);
        }
        
     }
};

MallincamGuider::~MallincamGuider()
{
    
};

#ifdef _WIN32
    mallincam_ports(HMallinCam) MallincamGuider::Mallincam_Open(const wchar_t* id)
#else
    mallincam_ports(HMallinCam) MallincamGuider::Mallincam_Open(const char* id)
#endif
{
    m_Hmallincam = (HMallinCam)_myOpenFunc(id);
    
    return m_Hmallincam;
};

MallincamModel MallincamGuider::GetCameraProperty(int i)
{
    MallincamInst inst = m_ti[i];
    const MallincamModel* mod = inst.model;
    return *mod;
};

mallincam_ports(unsigned) MallincamGuider::Mallincam_Enum(MallincamInst pti[MALLINCAM_MAX])
{
    ToupcamInst tmpInst[MALLINCAM_MAX];
    int retVal = _myEnumFunc(tmpInst);
    m_nIndex = retVal;
    
    for (int i = 0; i<retVal; i++)
    {
        if (tmpInst[i].id != NULL)
            strcpy(m_ti[i].id, tmpInst[i].id);
        
        //        if (tmpInst[i].displayname != NULL)
        //            strcpy(m_ti[i].displayname, tmpInst[i].displayname);
        
        const ToupcamModel *tmpModel = tmpInst[i].model;
        MallincamModel* newModel = new MallincamModel();
        
        //       if (tmpModel->name != NULL)
        //           strcpy((char *)newModel->name, (char *) tmpModel->name);
        
        //TODO rD
        // assign all model values
        newModel->flag = tmpModel->flag;
        newModel->maxspeed = tmpModel->maxspeed;
        newModel->preview = tmpModel->preview;
        newModel->still = tmpModel->still;
        newModel->res->height = tmpModel->res->height;
        newModel->res->width = tmpModel->res->width;
        
        m_ti[i].model = newModel;
        
        
    }
    return retVal;
};

mallincam_ports(MRESULT)      MallincamGuider::Mallincam_StartPullModeWithCallback(HMallinCam h, PMALLINCAM_EVENT_CALLBACK pEventCallback, void* pCallbackContext)
{
    MRESULT result =  _myPullFunc((HToupCam)h,  pEventCallback, pCallbackContext );
    return result;
}

mallincam_ports(MRESULT)      MallincamGuider::Mallincam_PullImage(HMallinCam h, void* pImageData, int bits, unsigned* pnWidth, unsigned* pnHeight)
{
    MRESULT result =  _myPullImageFunc((HToupCam)h,  pImageData, bits, pnWidth, pnHeight );
    return (MC_ERROR_CODE)result;
    
}

mallincam_ports(MRESULT)  MallincamGuider::Mallincam_Stop(HMallinCam h)
{
    MRESULT result =  _myStopFunc((HToupCam)h);
    return (MC_ERROR_CODE)result;
    
}
mallincam_ports(MRESULT)  MallincamGuider::Mallincam_get_Resolution(HMallinCam h, unsigned nResolutionIndex, int* pWidth, int* pHeight)
{
    MRESULT result =  _myGetResolutionFunc((HToupCam)h, nResolutionIndex, pWidth, pHeight);
    return (MC_ERROR_CODE)result;
    
}
mallincam_ports(MRESULT)  MallincamGuider::Mallincam_ST4PulseGuide(HMallinCam h, unsigned nDirect, unsigned nDuration)
{
    MRESULT result =  _myST4GuideFunc((HToupCam)h, nDirect, nDuration);
    return (MC_ERROR_CODE)result;

}

mallincam_ports(MRESULT)  MallincamGuider::Mallincam_get_ExpoAGainRange(HMallinCam h, unsigned short* nMin, unsigned short* nMax, unsigned short* nDef)
{
    MRESULT result =  _myGetGainRangeFunc((HToupCam)h, nMin, nMax, nDef);
    return (MC_ERROR_CODE)result;
    
}

mallincam_ports(MRESULT)  MallincamGuider::Mallincam_get_ExpoAGain(HMallinCam h, unsigned short* AGain)
{
    MRESULT result =  _myGetGainFunc((HToupCam)h, AGain);
    return (MC_ERROR_CODE)result;
    
}

mallincam_ports(MRESULT)  MallincamGuider::Mallincam_put_ExpoAGain(HMallinCam h, unsigned short AGain)
{
    MRESULT result =  _myPutGainFunc((HToupCam)h, AGain);
    return (MC_ERROR_CODE)result;
    
}
mallincam_ports(MRESULT)  MallincamGuider::Mallincam_get_ExpoTime(HMallinCam h, unsigned* Time)
{
    MRESULT result =  _myGetExpoTimeFunc((HToupCam)h, Time);
    return (MC_ERROR_CODE)result;
    
}

mallincam_ports(MRESULT)  MallincamGuider::Mallincam_put_ExpoTime(HMallinCam h, unsigned Time)
{
    MRESULT result =  _myPutExpoTimeFunc((HToupCam)h, Time);
    return (MC_ERROR_CODE)result;
    
}

mallincam_ports(MRESULT)  MallincamGuider::Mallincam_StartPushMode(HMallinCam h, PMALLINCAM_DATA_CALLBACK pDataCallback, void* pCallbackCtx)
{
    MRESULT result =  _myPushFunc((HToupCam)h,  pDataCallback, pCallbackCtx );
    return result;
  
}


