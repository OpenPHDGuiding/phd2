The MallinCam SkyRaider OSX camera support was provided by Randy
Pufahl in the form of a dylib wrapper, libmallincam.dylib, for an old
version of the ToupTek camera SDK library, renamed to
"MallincamGuider".  ToupTek declined our requests to provide a 32-bit
OSX SDK library, so we're using the old version with Randy's wrapper.

The compiled dylib files are in

thirdparty/frameworks/MallincamGuider.framework/

MallincamGuider-OSX-dylib-source.zip contains Randy's original source
code for libmallincam.dylib.  I'm adding this to the PHD2 repository
in case we ever need to rebuild libmallincam.dylib from source.
