/*
 * Starlight Xpress CCD INDI Driver
 * 
 * Copyright (c) 2012 Cloudmakers, s. r. o. All Rights Reserved.
 *
 */

#pragma once

#define VERSION_MAJOR 1
#define VERSION_MINOR 12
