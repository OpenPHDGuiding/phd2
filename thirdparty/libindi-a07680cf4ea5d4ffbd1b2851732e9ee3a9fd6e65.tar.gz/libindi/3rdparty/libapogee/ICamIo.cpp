/*! 
* 
* Copyright(c) 2009 Apogee Instruments, Inc. 
* \class ICamIo 
* \brief interface class for all camera io 
* 
*/ 

#include "ICamIo.h" 


//////////////////////////// 
// CTOR 
ICamIo::ICamIo() 
{ 

} 

//////////////////////////// 
// DTOR 
ICamIo::~ICamIo() 
{ 

}
