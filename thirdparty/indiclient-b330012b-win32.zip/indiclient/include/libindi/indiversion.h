/* Set INDI Library version */
#define INDI_VERSION 1.5.0

/* Define INDI Data Dir */
#define DATA_INSTALL_DIR "C:/cygwin/home/agalasso/tmp/indibuild/indiclient/share/indi/"
