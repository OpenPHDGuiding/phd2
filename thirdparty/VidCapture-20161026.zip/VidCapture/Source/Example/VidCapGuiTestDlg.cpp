// VidCapGuiTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "VidCapGuiTest.h"
#include "VidCapGuiTestDlg.h"
#include "VidCapture.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


// GUI refresh message (from capture thread)
#define VIDCAPGUI_REFRESH WM_APP + 1

/////////////////////////////////////////////////////////////////////////////
// CVidCapGuiTestDlg dialog

CVidCapGuiTestDlg::CVidCapGuiTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CVidCapGuiTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CVidCapGuiTestDlg)
	m_frameNumStr = _T("");
	m_captureRate = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
   m_frameNumber     = 0;
   m_lastFrameTime   = 0;
   memset(&m_frameTimes,0,sizeof(m_frameTimes));
}

void CVidCapGuiTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CVidCapGuiTestDlg)
	DDX_Control(pDX, IDC_WHITESLIDER, m_sliderWhite);
	DDX_Control(pDX, IDC_SHARPSLIDER, m_sliderSharp);
	DDX_Control(pDX, IDC_GAMMASLIDER, m_sliderGamma);
	DDX_Control(pDX, IDC_GAINSLIDER, m_sliderGain);
	DDX_Control(pDX, IDC_SATURATIONSLIDER, m_sliderSat);
	DDX_Control(pDX, IDC_HUESLIDER, m_sliderHue);
	DDX_Control(pDX, IDC_CONTRASTSLIDER, m_sliderContrast);
	DDX_Control(pDX, IDC_BRIGHTSLIDER, m_sliderBright);
	DDX_Control(pDX, IDC_MODELIST, m_modeList);
	DDX_Control(pDX, IDC_DEVICELIST, m_deviceList);
	DDX_Text(pDX, IDC_FRAMENUM, m_frameNumStr);
	DDX_Text(pDX, IDC_CAPTURERATE, m_captureRate);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CVidCapGuiTestDlg, CDialog)
	//{{AFX_MSG_MAP(CVidCapGuiTestDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_LBN_SELCHANGE(IDC_DEVICELIST, OnSelchangeDevicelist)
	ON_LBN_SELCHANGE(IDC_MODELIST, OnSelchangeModelist)
	ON_WM_DESTROY()
	ON_WM_HSCROLL()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVidCapGuiTestDlg message handlers

BOOL CVidCapGuiTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

   m_VidCapture = CVPlatform::GetPlatform()->AcquireVideoCapture();
   if (m_VidCapture == 0)
   {
      MessageBox("Failed to allocate video capture system.");
      PostQuitMessage(-1);
      return FALSE;
   }
   
   if (CVFAILED(m_VidCapture->Init()))
   {
      MessageBox("Failed to initialize video capture system.");
      CVPlatform::GetPlatform()->Release(m_VidCapture);
      PostQuitMessage(-1);
      return FALSE;
   }

   this->RefreshDevices();
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.
void CVidCapGuiTestDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CVidCapGuiTestDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CVidCapGuiTestDlg::RefreshDevices()
{
   m_modeList.ResetContent();
   m_deviceList.ResetContent();   
   m_VidCapture->RefreshDeviceList();
   
   int numDevices = 0;
   if (CVFAILED(m_VidCapture->GetNumDevices(numDevices)))
   {
      MessageBox("Error refreshing device list.");
      return;
   }

   for (int curDevice = 0; curDevice < numDevices; curDevice++)
   {
      CVVidCapture::VIDCAP_DEVICE devInfo;
      if (CVSUCCESS(m_VidCapture->GetDeviceInfo(curDevice,devInfo)))
      {
         int item = m_deviceList.InsertString(curDevice,devInfo.DeviceString);
         m_deviceList.SetItemData(item,curDevice);
      }
   }
}

void CVidCapGuiTestDlg::OnSelchangeDevicelist() 
{
   if (m_VidCapture->IsStarted())
   {
      m_VidCapture->Stop();
   }

   // Disconnect if we're connected.
   if (m_VidCapture->IsConnected())
   {
      m_VidCapture->Disconnect();
   }

   m_modeList.ResetContent();  
   m_frameNumber = 0;
   m_lastFrameTime = 0;
   memset(&m_frameTimes,0,sizeof(m_frameTimes));

   int item = m_deviceList.GetCurSel();	
   if (item == -1)
   {
      return;
   }

   int devIndex = m_deviceList.GetItemData(item);
   if (CVFAILED(m_VidCapture->Connect(devIndex)))
   {
      MessageBox("Could not connect to device!");
      return;
   }

   // Setup sliders....
   InitSlider(&m_sliderBright,   CVVidCapture::CAMERAPROP_BRIGHT,    IDC_BRIGHTLABEL);
   InitSlider(&m_sliderContrast, CVVidCapture::CAMERAPROP_CONTRAST,  IDC_CONTRASTLABEL);
   InitSlider(&m_sliderHue,      CVVidCapture::CAMERAPROP_HUE,       IDC_HUELABEL);
   InitSlider(&m_sliderSat,      CVVidCapture::CAMERAPROP_SAT,       IDC_SATLABEL);
   InitSlider(&m_sliderSharp,    CVVidCapture::CAMERAPROP_SHARP,     IDC_SHARPLABEL);
   InitSlider(&m_sliderGamma,    CVVidCapture::CAMERAPROP_GAMMA,     IDC_GAMMALABEL);
   InitSlider(&m_sliderWhite,    CVVidCapture::CAMERAPROP_WHITEBALANCE,  IDC_WHITELABEL);
   InitSlider(&m_sliderGain,    CVVidCapture::CAMERAPROP_GAIN,       IDC_GAINLABEL);

   RefreshModeList();
}

void CVidCapGuiTestDlg::RefreshModeList()
{
   
   m_modeList.ResetContent();

   if (m_VidCapture->IsConnected() == false)
   {
      MessageBox("Cannot refresh mode list - Please select a device first.");
      return;
   }

   int numModes;
   if (CVFAILED(m_VidCapture->GetNumSupportedModes(numModes)))
   {
      MessageBox("Failed retrieving available modes from camera");
      return;
   }

   for (int curMode = 0; curMode < numModes; curMode++)
   {
      CVVidCapture::VIDCAP_MODE modeInfo;
      if (CVSUCCESS(m_VidCapture->GetModeInfo(curMode,modeInfo)))
      {
         CString modeText;
         
         modeText.Format("%d x %d @ %d fps - %s",
                           modeInfo.XRes, 
                           modeInfo.YRes,
                           modeInfo.EstFrameRate,
                           m_VidCapture->GetFormatModeName(modeInfo.InputFormat));

         int item = m_modeList.InsertString(curMode, modeText);
         m_modeList.SetItemData(item, curMode);
      }
   }
}

void CVidCapGuiTestDlg::OnSelchangeModelist() 
{
   if (m_VidCapture->IsStarted())
   {
      m_VidCapture->Stop();
   }

   int item = m_modeList.GetCurSel();
   if (item < 0)
   {
      return;
   }

   int modeIndex = m_modeList.GetItemData(item);
   
   if (CVFAILED(m_VidCapture->SetMode(modeIndex)))
   {
      MessageBox("Failed to set mode!");
      return;
   }

   if (CVFAILED(m_VidCapture->StartImageCap(CVImage::CVIMAGE_RGB24,  CaptureCallback, this)))
   {
      MessageBox("Failed to start image capture!");   
   }

   m_frameNumber = 0;
   m_lastFrameTime = 0;
   memset(&m_frameTimes,0,sizeof(m_frameTimes));

}

void CVidCapGuiTestDlg::OnDestroy() 
{
   if (m_VidCapture != 0)
   {
      if (m_VidCapture->IsStarted())
      {
         m_VidCapture->Stop();
      }
      if (m_VidCapture->IsConnected())
      {
         m_VidCapture->Disconnect();
      }
      if (m_VidCapture->IsInitialized())
      {
         m_VidCapture->Uninit();
      }
      CVPlatform::GetPlatform()->Release(m_VidCapture);
      m_VidCapture = 0;
   }

	CDialog::OnDestroy();	
	// TODO: Add your message handler code here
	
}

LRESULT CVidCapGuiTestDlg::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
   switch (message)
   {
      case VIDCAPGUI_REFRESH:
         {
            this->UpdateData(TRUE);
            this->m_frameNumStr.Format("%d",m_frameNumber);
            
            // Calc avg frame time
            float accum = 0;
            float divisor = 0;
            for (int i = 0; i < kNUMFRAMESAVG; i++)
            {
               if (m_frameTimes[i] != 0)
               {
                  accum += m_frameTimes[i];
                  divisor++;
               }
            }

            if (divisor == 0)
            {
               this->m_captureRate = "0";
            }
            else
            {
               m_captureRate.Format("%.2f fps",(float)(CLOCKS_PER_SEC * divisor) / accum );
            }
          
            this->UpdateData(FALSE);         
            return TRUE;
         }
         break;
   }
	return CDialog::WindowProc(message, wParam, lParam);
}

void CVidCapGuiTestDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{

   // Bail if we're not connected to a camera.
   if ((!m_VidCapture) || (m_VidCapture->IsConnected() == false))
   {
      return;
   }

   long value = 0;
   CSliderCtrl* slider = (CSliderCtrl*)pScrollBar;

   if (slider == &m_sliderBright)
   {
      OnSlider(slider, CVVidCapture::CAMERAPROP_BRIGHT);
   }
   else if (slider == &m_sliderContrast)
   {
      OnSlider(slider, CVVidCapture::CAMERAPROP_CONTRAST);
   }
   else if (slider == &m_sliderSat)
   {
      OnSlider(slider, CVVidCapture::CAMERAPROP_SAT);      
   }
   else if (slider == &m_sliderHue)
   {
      OnSlider(slider, CVVidCapture::CAMERAPROP_HUE);
   }
   else if (slider == &m_sliderSharp)
   {
      OnSlider(slider, CVVidCapture::CAMERAPROP_SHARP);
   }
   else if (slider == &m_sliderGamma)
   {
      OnSlider(slider, CVVidCapture::CAMERAPROP_GAMMA);
   }
   else if (slider == &m_sliderGain)
   {
      OnSlider(slider, CVVidCapture::CAMERAPROP_GAIN);
   }
   else if (slider == &m_sliderWhite)
   {
      OnSlider(slider, CVVidCapture::CAMERAPROP_WHITEBALANCE);
   }
	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}


void CVidCapGuiTestDlg::OnSlider( CSliderCtrl* slider, CVVidCapture::CAMERA_PROPERTY property)
{
   long value = slider->GetPos();
   m_VidCapture->SetProperty(property, value);
}

void CVidCapGuiTestDlg::InitSlider(CSliderCtrl* slider, CVVidCapture::CAMERA_PROPERTY property, long labelId)
{      
   long curVal, defVal, minVal, maxVal,step;
   CVRES result;
   result = m_VidCapture->GetPropertyInfo( property, &curVal, &defVal, &minVal, &maxVal, &step);   
   if (CVFAILED(result))
   {
      slider->EnableWindow(FALSE);
      slider->SetRange(0,1,TRUE);
      slider->SetPos(0);
      GetDlgItem(labelId)->EnableWindow(FALSE);
   }
   else
   {
      GetDlgItem(labelId)->EnableWindow(TRUE);
      slider->EnableWindow(TRUE);
      slider->SetRange(minVal,maxVal,TRUE);
      slider->SetPos(curVal);
   }      
}


bool CVidCapGuiTestDlg::CaptureCallback( CVRES             status,
                                         CVImage*          imagePtr,
                                         void*             userParam)
{
   CVidCapGuiTestDlg* guiDlg = (CVidCapGuiTestDlg*)userParam;
   
   int frameTimeIndex = guiDlg->m_frameNumber % kNUMFRAMESAVG;
   
   int curTime = clock();
   
   if (guiDlg->m_lastFrameTime != 0)
   {
      guiDlg->m_frameTimes[frameTimeIndex] = curTime - guiDlg->m_lastFrameTime;
   }
   else
   {
      guiDlg->m_frameTimes[frameTimeIndex] = 0;
   }

   guiDlg->m_lastFrameTime = curTime;
      
   guiDlg->m_frameNumber++;
   guiDlg->PostMessage(VIDCAPGUI_REFRESH,0,0);
   return true;
}
