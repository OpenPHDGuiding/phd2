// VidCapGuiTestDlg.h : header file
//

#if !defined(AFX_VIDCAPGUITESTDLG_H__034355E8_3A5E_4595_A240_D450CD7DA7A3__INCLUDED_)
#define AFX_VIDCAPGUITESTDLG_H__034355E8_3A5E_4595_A240_D450CD7DA7A3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CVImage.h"
#include "CVVidCapture.h"

/////////////////////////////////////////////////////////////////////////////
// CVidCapGuiTestDlg dialog

#define kNUMFRAMESAVG 30

class CVidCapGuiTestDlg : public CDialog
{
// Construction
public:
	CVidCapGuiTestDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CVidCapGuiTestDlg)
	enum { IDD = IDD_VIDCAPGUITEST_DIALOG };
	CSliderCtrl	m_sliderWhite;
	CSliderCtrl	m_sliderSharp;
	CSliderCtrl	m_sliderGamma;
	CSliderCtrl	m_sliderGain;
	CSliderCtrl	m_sliderSat;
	CSliderCtrl	m_sliderHue;
	CSliderCtrl	m_sliderContrast;
	CSliderCtrl	m_sliderBright;
	CListBox	m_modeList;
	CListBox	m_deviceList;
	CString	m_frameNumStr;
	CString	m_captureRate;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVidCapGuiTestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
protected:
   CBitmap        m_curBmp;
	HICON          m_hIcon;
   CVVidCapture*  m_VidCapture;
   int            m_frameNumber;   
   int            m_frameTimes[kNUMFRAMESAVG];
   int            m_lastFrameTime;

   void RefreshDevices();
   void RefreshModeList();
   void SetMode(int index);
   
   void InitSlider(  CSliderCtrl* slider, 
                     CVVidCapture::CAMERA_PROPERTY property, 
                     long labelId);
   
   void OnSlider( CSliderCtrl* slider, CVVidCapture::CAMERA_PROPERTY property);

   static bool CaptureCallback( CVRES             status,
                                CVImage*          imagePtr,
                                void*             userParam);

   
	// Generated message map functions
	//{{AFX_MSG(CVidCapGuiTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSelchangeDevicelist();
	afx_msg void OnSelchangeModelist();
	afx_msg void OnDestroy();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VIDCAPGUITESTDLG_H__034355E8_3A5E_4595_A240_D450CD7DA7A3__INCLUDED_)
