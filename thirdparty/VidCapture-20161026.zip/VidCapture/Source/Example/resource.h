//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by VidCapGuiTest.rc
//
#define IDD_VIDCAPGUITEST_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDC_IMAGEFRAME                  1000
#define IDC_MODELIST                    1004
#define IDC_DEVICELIST                  1005
#define IDC_FRAMENUM                    1006
#define IDC_CAPTURERATE                 1007
#define IDC_BRIGHTSLIDER                1009
#define IDC_CONTRASTSLIDER              1010
#define IDC_HUESLIDER                   1011
#define IDC_SATURATIONSLIDER            1012
#define IDC_BRIGHTLABEL                 1013
#define IDC_CONTRASTLABEL               1014
#define IDC_HUELABEL                    1015
#define IDC_SATLABEL                    1016
#define IDC_SHARPSLIDER                 1017
#define IDC_SHARPLABEL                  1018
#define IDC_GAMMASLIDER                 1019
#define IDC_GAMMALABEL                  1020
#define IDC_GAINSLIDER                  1021
#define IDC_GAINLABEL                   1022
#define IDC_BACKLIGHT                   1025
#define IDC_WHITELABEL                  1026
#define IDC_WHITESLIDER                 1027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
