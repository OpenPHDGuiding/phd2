// VidCapGuiTest.h : main header file for the VIDCAPGUITEST application
//

#if !defined(AFX_VIDCAPGUITEST_H__64F97633_FAD5_4555_AD50_E93D5B79BC66__INCLUDED_)
#define AFX_VIDCAPGUITEST_H__64F97633_FAD5_4555_AD50_E93D5B79BC66__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CVidCapGuiTestApp:
// See VidCapGuiTest.cpp for the implementation of this class
//

class CVidCapGuiTestApp : public CWinApp
{
public:
	CVidCapGuiTestApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVidCapGuiTestApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CVidCapGuiTestApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VIDCAPGUITEST_H__64F97633_FAD5_4555_AD50_E93D5B79BC66__INCLUDED_)
