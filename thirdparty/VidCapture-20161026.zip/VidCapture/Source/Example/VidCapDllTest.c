/*
// VidCapDllTest.c
// Test and sample program for CodeVis VidCapture DLL (VidCapDll.dll)
// Written by Michael Ellison
//-------------------------------------------------------------------------
//                      CodeVis's Free License
//                         www.codevis.com
//
// Copyright (c) 2003 by Michael Ellison (mike@codevis.com)
// All rights reserved.
//
// You may use this software in source and/or binary form, with or without
// modification, for commercial or non-commercial purposes, provided that 
// you comply with the following conditions:
//
// * Redistributions of source code must retain the above copyright notice,
//   this list of conditions and the following disclaimer. 
//
// * Redistributions of modified source must be clearly marked as modified,
//   and due notice must be placed in the modified source indicating the
//   type of modification(s) and the name(s) of the person(s) performing
//   said modification(s).
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
// LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//---------------------------------------------------------------------------
// Modifications:
//
//---------------------------------------------------------------------------
/// \file VidCapDllTest.c
/// \brief Test and sample program for CodeVis VidCapture DLL (VidCapDll.dll)
///
/// This program is a feature test of the VidCapture DLL (VidCapDll.dll).
/// It shows how to perform simple image capture tasks for WebCams
/// with the DirectShow interface from Microsoft.
///
/// You'll need a recent version of DirectX and a WebCamera.
///
/// Compiled and tested with Visual C++ 6.0 and a Logitech Quickcam 4000.
///
///
/// $RCSfile: VidCapDllTest.c,v $
/// $Date: 2004/03/01 16:28:15 $
/// $Revision: 1.3 $
/// $Author: mikeellison $
*/

#include <windows.h>
#include <stdio.h>

#include "VidCapDll.h"

/* Device number to use in tests */
#define DEVICENUMBER 0
/* Mode index to use in tests */
#define MODENUMBER   0

/*
   ImageCallback is the callback used by 
   the continuous capture run 
*/
BOOL WINAPI ImageCallback( CVRES status, 
                           struct CVIMAGESTRUCT* image,
                           void* userParam);

int main(int argc, char** argv)
{
   CVVIDCAPSYSTEM capSystem;         /* Handle for video capture system */
   CVCAPHANDLE    capHandle;         /* Handle for a capture run */

   struct CVIMAGESTRUCT* imagePtr;   /* Image pointer for direct grabs */
   char   vidCapString[256];         /* String buffer to receive (c) str */
   int    vidCapStrBuf;              /* String buffer size */
   int    numDevices;                /* Number of available devices in system */
   char   devName[256];              /* String buffer for device name */
   int    devNameLen;                /* Length of device name */
   int    numModes;                  /* Number of modes available on device */
   int    xRes;                      /* Horizontal resolution of mode */
   int    yRes;                      /* Vertical resolution of mode */
   int    i;                         /* Generic index counter */
   long   curPropVal,
          propStep,
          defPropVal,
          minPropVal,
          maxPropVal;                /* Property values of camera */

   CVRES  result;                    /* Result code */

   int frameRate;                    /* estimated frame rate of mode */
   int vidFormat;                    /* Video format for mode */
   int vidFmtNameLen;                /* Length of video format name */
   char vidFormatName[32];           /* video format name buffer */
           
   vidCapStrBuf = 255;
   CVGetVidCapString(vidCapString,&vidCapStrBuf);

   printf("-------------------------------------------------------\n");
   printf("CodeVis VidCapture DLL Test Program                     \n");
   printf("%s",vidCapString);
   printf("-------------------------------------------------------\n");
   
   
   /* Acquire the video capture system */
   if (CVFAILED(CVAcquireVidCap(&capSystem)))
   {
      printf("Error acquiring capture system.\n");
      return -1;
   }

   /* Enumerate available devices */
   numDevices = CVGetNumDevices(capSystem);

   if (numDevices == 0)
   {
      printf("No compatible devices found. Please install a web camera.\n");
      CVReleaseVidCap(capSystem);
      return -1;
   }

   /* List Devices */
   for (i = 0; i < numDevices; i++)
   {
      devNameLen = 255;
      if (CVSUCCESS(CVGetDeviceName(capSystem, i, devName, &devNameLen)))
      {
         printf("Found device: %d - %s\n",i,devName);
      }
   }

   /* Get the first device and connect to it */
   devNameLen = 255;
   CVGetDeviceName(capSystem,DEVICENUMBER,devName,&devNameLen);
   printf("Selecting the first one: %s\n",devName);
   
   if (CVFAILED(CVDevConnect(capSystem,DEVICENUMBER)))
   {
      printf("Failed connecting to camera: %s\n",devName);
      CVReleaseVidCap(capSystem);
      return -1;
   }

   /* List available camera modes */   

   printf("Scanning available modes...\n");
   numModes = CVDevGetNumModes(capSystem);
   for (i = 0; i < numModes; i++)
   {
      if (CVSUCCESS(CVDevGetModeInfo(capSystem,i,&xRes, &yRes, &frameRate, &vidFormat)))
      {
         vidFmtNameLen = 32;                  
         CVDevGetFormatName(capSystem,vidFormat,vidFormatName, &vidFmtNameLen);
         printf("Mode %d: %dx%d @ %d frames/sec (%s)\n",i,xRes,yRes, frameRate, vidFormatName);
      }
   }
   
   /* Grab an image in the first mode */
   if (CVSUCCESS(CVDevGrabImage(capSystem,MODENUMBER,CVIMAGETYPE_RGB24,&imagePtr)))
   {
      printf("Grabbed an image - saving as TestImage.ppm\n");

      /* Save the image as a PPM file */
      if (CVFAILED(CVSaveImage("TestImage.ppm",imagePtr,TRUE)))
      {
         printf("Image save failed!\n");
      }

      /* Release the image data */
      CVReleaseImage(imagePtr);
   }
   else
   {
      printf("Failed grabbing in mode 0.\n");
   }

   
   /* Test some properties of the camera */
   result = CVDevGetProperty( capSystem,
                              CVCAM_BRIGHT,
                              &curPropVal,
                              &defPropVal,
                              &minPropVal,
                              &maxPropVal,
                              &propStep);

   if (result == CVRES_DLL_VIDCAP_UNSUPPORTED_PROPERTY)
   {
      printf("Brightness unsupported on camera.\n");
   }
   else if (CVFAILED(result))
   {
      printf("Error retrieving brightness information.\n");
   }
   else
   {
      printf("Brightness property:\n");
      printf("\tCurrent: %d\n", curPropVal);
      printf("\tDefault: %d\n", defPropVal);
      printf("\tMinimum: %d\n", minPropVal);
      printf("\tMaximum: %d\n", maxPropVal);
      printf("\tStep: %d\n", propStep);
   }

   /* Take a dark image */
   CVDevSetProperty( capSystem, CVCAM_BRIGHT, minPropVal);
   if (CVSUCCESS(CVDevGrabImage(capSystem,MODENUMBER,CVIMAGETYPE_RGB24,&imagePtr)))
   {
      printf("Grabbed an image - saving as DarkImage.ppm\n");
      if (CVFAILED(CVSaveImage("DarkImage.ppm",imagePtr,TRUE)))
      {
         printf("Image save failed!\n");
      }
      CVReleaseImage(imagePtr);
   }
   else
   {
      printf("Failed grabbing image.\n");
   }


   /* Take a light image */
   CVDevSetProperty( capSystem, CVCAM_BRIGHT, maxPropVal);
   if (CVSUCCESS(CVDevGrabImage(capSystem,MODENUMBER,CVIMAGETYPE_RGB24,&imagePtr)))
   {
      printf("Grabbed an image - saving as LightImage.ppm\n");
      if (CVFAILED(CVSaveImage("LightImage.ppm",imagePtr,TRUE)))
      {
         printf("Image save failed!\n");
      }
      CVReleaseImage(imagePtr);
   }
   else
   {
      printf("Failed grabbing image.\n");
   }


   /* Restore the original value */
   CVDevSetProperty( capSystem, CVCAM_BRIGHT, curPropVal);



   /* Start a continuous grab */
   CVDevStartCap(capSystem, MODENUMBER, CVIMAGETYPE_RGB24, ImageCallback, 0, &capHandle);

   /* Wait 2 seconds and let it grab some images */
   Sleep(2000);

   /* End the continuous grab */
   CVDevStopCap(capSystem, capHandle);

   /* Disconnect and release the system handle */
   printf("\nCleaning up...\n");
   CVDevDisconnect(capSystem);
   CVReleaseVidCap(capSystem);
   printf("Test complete.\n");
   
   return 0;
}


/* 
   ImageCallback is the callback used by 
   the continuous capture run 
*/
BOOL WINAPI ImageCallback( CVRES status, 
                           struct CVIMAGESTRUCT* image,
                           void* userParam)
{
   static int curImageNum = 0;

   if (CVFAILED(status))
   {
      printf("Got a failed status in the image callback!");
   }
   else
   {
      if (CVFAILED(CVSaveImage("LastImage.ppm",image,TRUE)))
      {
         printf("\nFailed to save an image in callback!\n");
      }
      curImageNum++;
      printf("Captured image: %d\r",curImageNum);
   }
   
   /*
      Return FALSE here to end the capture run.  If you do this,
      you still have to call CVDevStopCap() to clean up afterwards!
   */
   return TRUE;
}