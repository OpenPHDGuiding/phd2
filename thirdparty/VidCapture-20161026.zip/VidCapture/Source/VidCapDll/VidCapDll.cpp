// VidCapDll.cpp
// C-style DLL wrapper for VidCapture library
// Written by Michael Ellison
//-------------------------------------------------------------------------
//                      CodeVis's Free License
//                         www.codevis.com
//
// Copyright (c) 2004 by Michael Ellison (mike@codevis.com)
// All rights reserved.
//
// You may use this software in source and/or binary form, with or without
// modification, for commercial or non-commercial purposes, provided that 
// you comply with the following conditions:
//
// * Redistributions of source code must retain the above copyright notice,
//   this list of conditions and the following disclaimer. 
//
// * Redistributions of modified source must be clearly marked as modified,
//   and due notice must be placed in the modified source indicating the
//   type of modification(s) and the name(s) of the person(s) performing
//   said modification(s).
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
// LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//---------------------------------------------------------------------------
// Modifications:
//
//---------------------------------------------------------------------------
/// \file VidCapDll.cpp
/// \brief C-style DLL wrapper for VidCapture library
///
/// $RCSfile: VidCapDll.cpp,v $
/// $Date: 2004/03/01 18:31:06 $
/// $Revision: 1.4 $
/// $Author: mikeellison $

#include <windows.h>
#include "VidCapDll.h"
#include "CVResDll.h"
#include "CVUtil.h"
#include "VidCapture.h"

/// Internal function to create an image structure from an image class.
CVRES CVImgStructFromImage( CVIMAGESTRUCT** imageStructPtrPtr, 
                            CVImage*        image);

//-------------------------------------------------------------------------
/// DLLMain() - DLL entry point...
/// Do we need to set aside thread storage? Hopefully not for now. 
/// To make things work between threads/apps we just create
/// an entirely new CVVidCapture instance for each caller and
/// then use that as a handle.
//-------------------------------------------------------------------------
BOOL WINAPI DllMain(HINSTANCE hInst, DWORD dwReason, LPVOID lpvReserved)
{   
   switch (dwReason)
   {
      /// Process starting....
      case DLL_PROCESS_ATTACH:
         ::OutputDebugString(kVIDCAPTURE_STRING);
         break;
                 
      /// Process exiting...
      case DLL_PROCESS_DETACH:
         ::OutputDebugString("VidCapture DLL Detatched...\n");
         break;

      default:
         break;
   }
   return TRUE;
}



//-------------------------------------------------------------------------
/// CVAcquireVidCap() acquires a video capture object and initializes it.
/// You must call CVReleaseVidCap() when done with the handle returned
/// on a successful call.
///
/// \param capSystem - ref to handle. Contains new handle on success.
/// \return CVRES - CVRES_SUCCESS on successful initialization.
///
/// \sa CVReleaseVidCap()
//-------------------------------------------------------------------------
CVRES VIDCAPFUNC CVAcquireVidCap(CVVIDCAPSYSTEM* capSystem)
{  
   if (capSystem == 0)
   {
      return CVRES_INVALID_PARAMETER;
   }
    
   CVRES result = CVRES_SUCCESS;
   *capSystem = 0;

   CVVidCapture* vidCap = CVPlatform::GetPlatform()->AcquireVideoCapture();
   if (vidCap != 0)
   {
      if (CVSUCCESS(result = vidCap->Init()))
      {
         /// Successful - save handle and return
         *capSystem = (CVVIDCAPSYSTEM)vidCap;
         return CVRES_SUCCESS;
      }
      
      /// Didn't initialize properly - uninitialize and return error.
      CVPlatform::GetPlatform()->Release(vidCap);
      return result;
   }
   else
   {      
      return CVRES_DLL_VIDCAP_CREATE_ERROR;
   }
}

//-------------------------------------------------------------------------
/// CVReleaseVidCap() releases a previously allocated video capture object.
///
/// \param capSystem - handle from CVACquireVidCap(). 
/// \sa CVAcquireVidCap()
//-------------------------------------------------------------------------
CVRES VIDCAPFUNC CVReleaseVidCap(CVVIDCAPSYSTEM capSystem)
{
   CVRES result = CVRES_SUCCESS;

   if (capSystem != 0)
   {
      if (((CVVidCapture*)capSystem)->IsInitialized())
      {
         result = ((CVVidCapture*)capSystem)->Uninit();
      }

      CVPlatform::GetPlatform()->Release( (CVVidCapture*&)capSystem);
   }

   return result;
}




//-------------------------------------------------------------------------
/// CVGetNumDevices() retrieves the number of capture devices
/// available to the VidCap .DLL.
///
/// \param capSystem - handle from CVAcquireVidCap()
/// \return int - number of available capture devices.
//-------------------------------------------------------------------------
int VIDCAPFUNC CVGetNumDevices( CVVIDCAPSYSTEM capSystem)
{
   CVAssert(capSystem != 0, "Invalid video capture handle");
   if (capSystem == 0)
   {
      return 0; ///CVRES_DLL_VIDCAP_INVALID_HANDLE
   }   
   CVVidCapture* vidCap = (CVVidCapture*)capSystem;

   int numDevices = 0;
   vidCap->GetNumDevices(numDevices);
   
   return numDevices;
}



//-------------------------------------------------------------------------
/// CVFINDDEVINFO is used to pass the device information
/// from CVGetDeviceName() to the FindDeviceCB() callback
/// and back when looking for a specific device.  
///
/// It is not used outside of these functions.
//-------------------------------------------------------------------------
struct CVFINDDEVINFO
{  
   int ReqDev;          /// Requested device
   int CurDev;          /// Current device in enumeration
   char DevName[256];   /// Device name (if found)
};

//-------------------------------------------------------------------------
/// FindDeviceCB is a callback for CVVidCapture::EnumDevices.
/// It counts devices until it finds the requested one,
/// then saves the device name.  
///
/// This method isn't particularly efficient - later we should store a 
/// list but refresh it periodically or on the appropriate 
/// WM_DEVICECHANGE message.
//-------------------------------------------------------------------------
bool FindDeviceCB(   const char*             devname, 
                     void*                   userParam)
{
   CVFINDDEVINFO* findDevPtr = (CVFINDDEVINFO*)userParam;
   if (findDevPtr == 0)
      return false;

   if (findDevPtr->CurDev == findDevPtr->ReqDev)
   {
      strncpy(findDevPtr->DevName,devname,255);
      return false;
   }

   findDevPtr->CurDev++;
   return true;
}

//-------------------------------------------------------------------------
/// CVGetDeviceName() retrieves the name of a capture device
/// into the provided buffer.
///
/// \param capSystem  - handle from CVAcquireVidCap()
/// \param deviceNum     - index of device (0 -> CVGetNumDevices() - 1)
/// \param devNameBuffer - buffer to receive ASCIIZ device name.
///                        must be allocated by caller!
/// \param nameBufLen    - ptr to Maximum length of devNameBuffer.
///                        set to length of device name on return.
///
/// \return CVRES - CVRES_SUCCESS on success.
/// \sa CVGetNumDevices(), CVDevConnect()
//-------------------------------------------------------------------------
CVRES   VIDCAPFUNC CVGetDeviceName( CVVIDCAPSYSTEM capSystem,
                                    int          deviceNum,
                                    char*        devNameBuffer,
                                    int*         nameBufLen)
{
   CVAssert(nameBufLen != 0, "Need a name buffer length.");
   if (nameBufLen == 0)
   {
      return CVRES_INVALID_PARAMETER;
   }

   CVAssert(capSystem != 0, "Invalid video capture handle");
   if (capSystem == 0)
   {
      return CVRES_DLL_VIDCAP_INVALID_HANDLE;
   }   
   CVVidCapture* vidCap = (CVVidCapture*)capSystem;
   

   CVVidCapture::VIDCAP_DEVICE deviceInfo;
   CVRES result;
   if (CVFAILED(result = vidCap->GetDeviceInfo(deviceNum, deviceInfo)))
   {
      if (devNameBuffer != 0)
         devNameBuffer[0] = 0;
      return result;
   }

   if ((deviceInfo.DeviceString != 0) && (deviceInfo.DeviceString[0] != 0))
   {     
      if (devNameBuffer != 0)
      { 
         strncpy(devNameBuffer,deviceInfo.DeviceString,*nameBufLen);
      }
      *nameBufLen = strlen(deviceInfo.DeviceString);
      return CVRES_SUCCESS;
   }

   return CVRES_DLL_VIDCAP_DEV_NOT_FOUND;
}


//-------------------------------------------------------------------------
/// CVDevConnect() connects to the specified device.
/// Only one device should be connected at a time.
///
/// Call CVDevDisconnect() then done with the capture device handle.
///
/// \param capSystem - handle from CVAcquireVidCap()
/// \param devIndex - index of device (from GetDeviceName/GetNumDevices)
/// \return CVRES - CVRES_SUCCESS on success
/// \sa CVDevDisconnect(), CVGetDeviceName(), CVAcquireVidCap()
//-------------------------------------------------------------------------
CVRES   VIDCAPFUNC CVDevConnect   ( CVVIDCAPSYSTEM capSystem,
                                    int            devIndex)
{
   CVAssert(capSystem != 0, "Invalid video capture handle");
   if (capSystem == 0)
   {
      return CVRES_DLL_VIDCAP_INVALID_HANDLE;
   }   
   CVVidCapture* vidCap = (CVVidCapture*)capSystem;
   
   return vidCap->Connect(devIndex);
}


//-------------------------------------------------------------------------
/// CVDevDisconnect() disconnects a previously connected device.
/// CVDevDisconnect() should be called when done with a capture
/// device connected via CVDevConnect().
///
/// \param capSystem - handle from CVAcquireVidCap()
/// \return CVRES - CVRES_SUCCESS on success
/// \sa CVDevCOnnect()
//-------------------------------------------------------------------------
CVRES   VIDCAPFUNC CVDevDisconnect( CVVIDCAPSYSTEM capSystem )
{
   CVAssert(capSystem != 0, "Invalid video capture handle");
   if (capSystem == 0)
   {
      return CVRES_DLL_VIDCAP_INVALID_HANDLE;
   }   
   CVVidCapture* vidCap = (CVVidCapture*)capSystem;
   return vidCap->Disconnect();
}


//-------------------------------------------------------------------------
/// CVDevGetNumModes() retrieves the number of available mode
/// on a connected capture device.
///
/// You *must* connect to a device before you can retrieve the
/// available modes for it. If you do not, you'll just get
/// 0 for the number of modes.
///
/// \param capSystem - handle from CVAcquireVidCap()
/// \return int - number of modes available for the connected device
//-------------------------------------------------------------------------
int VIDCAPFUNC CVDevGetNumModes( CVVIDCAPSYSTEM capSystem )                                     
{
   CVAssert(capSystem != 0, "Invalid video capture handle");
   if (capSystem == 0)
   {
      return 0;
   }   
   CVVidCapture* vidCap = (CVVidCapture*)capSystem;
   
   int numModes = 0;
   if (CVSUCCESS(vidCap->GetNumSupportedModes(numModes)))
   {
      return numModes;
   }

   /// An error occurred...
   return 0;
}


//-------------------------------------------------------------------------
/// CVDevGetModeInfo() retrieve information about the specified
/// mode.
///
/// \param capSystem - handle from CVAcquireVidCap()
/// \param modeIndex - index of mode to use for capture
/// \param xRes - ptr to receive x resolution of the camera mode
/// \param yRes - ptr to receive y resolution of the camera mode
/// \param frameRate - ptr to receive estimated framerate (may be null)
/// \param vidFormat - ptr to receive input video mode value (VIDCAP_FORMAT)
///                    may be null.
/// \return CVRES - CVRES_SUCCESS on success
/// \sa CVDevGetNumModes(), CVDevConnect(), 
//-------------------------------------------------------------------------
CVRES   VIDCAPFUNC CVDevGetModeInfo( CVVIDCAPSYSTEM capSystem,
                                     int          modeIndex,
                                     int*         xRes,
                                     int*         yRes,
                                     int*         frameRate,
                                     int*         vidFormat)
{
   CVAssert((xRes != 0) && (yRes != 0), "need xRes and yRes pointers to be valid!");
   if ((xRes == 0) || (yRes == 0))
   {
      return CVRES_INVALID_PARAMETER;
   }

   // Initialize the values...   
   *xRes = 0;
   *yRes = 0;
   if (frameRate != 0)
      *frameRate = 0;

   if (vidFormat != 0)
      *vidFormat = 0;

   CVAssert(capSystem != 0, "Invalid video capture handle");
   if (capSystem == 0)
   {
      return CVRES_DLL_VIDCAP_INVALID_HANDLE;
   }   
   CVVidCapture* vidCap = (CVVidCapture*)capSystem;
   CVVidCapture::VIDCAP_MODE modeInfo;
      
   CVRES result = vidCap->GetModeInfo( modeIndex, modeInfo);
   if (CVFAILED(result))
   {
      return result;
   }

   *xRes = modeInfo.XRes;
   *yRes = modeInfo.YRes;
   if (frameRate)
      *frameRate = modeInfo.EstFrameRate;
   
   if (vidFormat)
      *vidFormat = modeInfo.InputFormat;

   return CVRES_SUCCESS;
}

//-------------------------------------------------------------------------
/// CVDevGetFormatName() retrieves the name of the video format
/// for a camera mode.
///
/// \param capSystem - handle from CVAcquireVidCap()
/// \param vidFormat - video format type (from CVDevGetModeInfo)
/// \param vidFormatNameBuf - ptr to buffer to receive format name
/// \param vidFormatBufLen - ptr to length of buffer. set to length of
///                          name on return.
/// \return CVRES - CVRES_SUCCESS on success
/// \sa CVDevGetModeInfo()
//-------------------------------------------------------------------------
CVRES VIDCAPFUNC CVDevGetFormatName( CVVIDCAPSYSTEM   capSystem,                                 
                                     int              vidFormat,
                                     char*            vidFormatNameBuf,
                                     int*             vidFormatBufLen)
{
   if (capSystem == 0)
   {
      return CVRES_DLL_VIDCAP_INVALID_HANDLE;
   }   
   CVVidCapture* vidCap = (CVVidCapture*)capSystem;
   
   if ((vidFormat < 0) || (vidFormat > VIDCAP_NUM_FORMATS))
   {
      return CVRES_VIDCAP_VIDEO_FORMAT_NOT_SUPPORTED;
   }

   if (vidFormatBufLen == 0)
   {
      return CVRES_INVALID_PARAMETER;
   }

   const char* formatName = vidCap->GetFormatModeName((VIDCAP_FORMAT)vidFormat);   
   
   if (vidFormatNameBuf != 0)
   {
      strncpy(vidFormatNameBuf,formatName,*vidFormatBufLen);
   }
   
   *vidFormatBufLen = strlen(formatName);
   
   return CVRES_SUCCESS;      
}

//-------------------------------------------------------------------------
/// CVDevGrabImage() grabs a single image from a selected and
/// connected camera.
///
/// You must free the returned pointer when done by calling
/// CVReleaseImage() on it or you will leak massive amounts of
/// memory.
///
/// \param capSystem - handle from CVAcquireVidCap()
/// \param modeIndex - index of mode to use for capture
/// \param imageType - requested type of image
/// \param imageStructPtrPtr - ptr to receive a ptr to created image struct.
///        Call CVReleaseImage() on the returned image struct ptr when done.
/// \return CVRES - CVRES_SUCCESS on success
/// \sa CVDevGetModeInfo()
//-------------------------------------------------------------------------
CVRES   VIDCAPFUNC CVDevGrabImage(   CVVIDCAPSYSTEM     capSystem,
                                     int              modeIndex,
                                     CVIMAGETYPE      imageType,
                                     CVIMAGESTRUCT**  imageStructPtrPtr)
{
   /// Check validity of image struct**, then set
   /// it to null in case something fails.
   if (imageStructPtrPtr == 0)
   {
      return CVRES_INVALID_PARAMETER;
   }

   *imageStructPtrPtr = 0;

   CVAssert(capSystem != 0, "Invalid video capture handle");
   if (capSystem == 0)
   {
      return CVRES_DLL_VIDCAP_INVALID_HANDLE;
   }   

   CVVidCapture* vidCap = (CVVidCapture*)capSystem;

   /// Select mode for grab
   CVRES result = vidCap->SetMode(modeIndex);
   if (CVFAILED(result))
   {
      return result;
   }

   /// Perform the grab
   CVImage* grabbedImage = 0;
   result = vidCap->Grab((CVImage::CVIMAGE_TYPE)imageType,grabbedImage);
   if (CVFAILED(result))
   {
      return result;
   }

   result = CVImgStructFromImage(imageStructPtrPtr, grabbedImage);
   CVImage::ReleaseImage(grabbedImage);
   if (CVFAILED(result))
      return result;

   return CVRES_SUCCESS;
}


//-------------------------------------------------------------------------
//// DLLCAPTURESTRUCT is used to pass data from CVDevStartCap
/// to subsequent capture callbacks.
//-------------------------------------------------------------------------
struct DLLCAPTURESTRUCT
{
   CVVIDCAPDLLCB HostCallback;   /// Host's callback function for capture
   void*         HostUserParam;  /// Host's user param for callbacks
};

//-------------------------------------------------------------------------
/// DllCaptureCb() is a passthrough for the capture callback from
/// CVVidCapture() to the host program.  
///
/// It converts the CVImage* to a CVIMAGESTRUCT*, then calls the
/// host.
///
//-------------------------------------------------------------------------
bool DllCaptureCb(   CVRES    status,
                     CVImage* capturedImage,
                     void*    userParam )
{
   DLLCAPTURESTRUCT* capStruct = (DLLCAPTURESTRUCT*)userParam;
   if (capStruct == 0)
      return false;
   
   /// If we have an image, convert it to an image struct
   if (CVSUCCESS(status) && (0 != capturedImage))
   {
      /// Unlike the image grabs, we don't waste time copying the memory out.
      /// Just fill in the struct, then point to the CVImage's pixel data.
      CVIMAGESTRUCT imgStruct;
      imgStruct.Version         = kCVIMAGESTRUCTVER;   
      imgStruct.ImageType       = (CVIMAGETYPE)capturedImage->GetImageType();
      imgStruct.BytesPerPixel   = capturedImage->GetBytesPerPixel();
      imgStruct.NumChannels     = capturedImage->GetNumChannels();   
      imgStruct.ImageHeight     = capturedImage->Height();
      imgStruct.ImageWidth      = capturedImage->Width();   
      imgStruct.ImageDataSize   = imgStruct.ImageWidth * 
                                  imgStruct.ImageHeight * 
                                  imgStruct.BytesPerPixel;
      imgStruct.PixelDataPtr    = capturedImage->GetRawDataPtr();
   
      return capStruct->HostCallback(  
                           status, 
                           &imgStruct, 
                           capStruct->HostUserParam)?true:false;
      
   }
   else
   {
      /// No image to pass - just call callback and return result.
      return capStruct->HostCallback(
                           status,
                           0,
                           capStruct->HostUserParam)?true:false;
   }
}

//-------------------------------------------------------------------------
/// CVDevStartCap() starts a continuous capture, sending each
/// image to the specified callback.
///
/// The CVIMAGESTRUCT* passed to the callback is *only* valid
/// during the callback!  You must copy the data out if you'll
/// need it later.  However, you should NOT call
/// CVReleaseImage() on it - the DLL will do that for you
/// when your callback function returns.
///
/// \param capSystem - handle from CVAcquireVidCap()
/// \param modeIndex - index of mode to use for capture
/// \param imageType - type of image to capture
/// \param callback - callback to receive images during capture
/// \param cbUserParam - user parameter to send to callback
/// \param capHandlePtr - ptr to receive capture handle.
/// \return CVRES - CVRES_SUCCESS on success
//-------------------------------------------------------------------------
CVRES   VIDCAPFUNC CVDevStartCap(    CVVIDCAPSYSTEM  capSystem,
                                     int           modeIndex,                                        
                                     CVIMAGETYPE   imageType,
                                     CVVIDCAPDLLCB callback,
                                     void*         cbUserParam,
                                     CVCAPHANDLE*  capHandlePtr)
{
   CVAssert(capSystem != 0, "Invalid video capture handle");
   if (capSystem == 0)
   {
      return CVRES_DLL_VIDCAP_INVALID_HANDLE;
   }   

   /// Create a capture structure for our callback
   DLLCAPTURESTRUCT* capStruct = new DLLCAPTURESTRUCT;
   capStruct->HostCallback     = callback;
   capStruct->HostUserParam    = cbUserParam;

   CVVidCapture* vidCap = (CVVidCapture*)capSystem;
   CVRES result = vidCap->StartImageCap(  (CVImage::CVIMAGE_TYPE)imageType,
                                          DllCaptureCb,
                                          capStruct);

   /// If we didn't start successfully, clean up the capture struct
   if (CVFAILED(result))
   {
      delete capStruct;
   }

   *capHandlePtr = (CVCAPHANDLE)capStruct;
   return result;
}


//-------------------------------------------------------------------------
/// CVDevStopCap() halts an image capture session started
/// by CVDevStartCap().
///
/// This must be called for cleanup even if the capture is stopped 
/// prematurely by an error or by returning false from
/// within the callback function.
///
/// \param capSystem - vidcap handle from CVAcquireVidCap()   
/// \param capHandle - cap handle received from CVDevStartCap()
//-------------------------------------------------------------------------
CVRES   VIDCAPFUNC CVDevStopCap( CVVIDCAPSYSTEM capSystem,
                                 CVCAPHANDLE  capHandle)
{
   CVAssert(capSystem != 0, "Invalid video capture handle");
   if (capSystem == 0)
   {
      return CVRES_DLL_VIDCAP_INVALID_HANDLE;
   }
   
   CVRES result = CVRES_SUCCESS;   
   CVVidCapture* vidCap = (CVVidCapture*)capSystem;
   if (vidCap != 0)
   {
      result = vidCap->Stop();
   }

   /// Cleanup the capture structure
   DLLCAPTURESTRUCT* capStruct = (DLLCAPTURESTRUCT*)capHandle;
   if (capStruct)
   {
      delete capStruct;
   }
   else
   {
      return CVRES_INVALID_PARAMETER;
   }

   return result;
}
                                                                                
//-------------------------------------------------------------------------
/// CVLoadImage() loads an image from the specified .ppm/.pgm file.
///
/// You must release it with CVReleaseImage() when done.
///
/// \param filename - pointer to ASCIIZ filename of .ppm/.pgm file.
/// \param imageStructPtrPtr - ptr to receive a ptr to created image struct.
///        Call CVReleaseImage() on the returned image struct ptr when done.
/// \sa CVReleaseImage(), CVSaveImage()
//-------------------------------------------------------------------------
CVRES VIDCAPFUNC CVLoadImage( const char*       filename,
                              CVIMAGESTRUCT**   imageStructPtrPtr)
{
   /// Check validity of image struct**, then set
   /// it to null in case something fails.
   if (imageStructPtrPtr == 0)
   {
      return CVRES_INVALID_PARAMETER;
   }
   *imageStructPtrPtr = 0;
   
   /// Load in the image
   CVImage* loadImage = 0;
   CVRES result = CVImage::Load(filename, loadImage);
   if (CVFAILED(result))
   {
      return result;
   }

   /// Convert image object to our struct type
   result = CVImgStructFromImage( imageStructPtrPtr, loadImage);
   CVImage::ReleaseImage(loadImage);
   
   if (CVFAILED(result))
   {
      return result;
   }

   return CVRES_SUCCESS;
}

//-------------------------------------------------------------------------
/// CVSaveImage() saves an image from a CVIMAGESTRUCT* to disk.
///
/// \param filename - pointer to ASCIIZ filename of .ppm/.pgm file.
/// \param imageStructPtr - ptr to image struct
/// \param overwrite - TRUE to overwrite existing files, FALSE otherwise.
/// \sa CVLoadImage()
//-------------------------------------------------------------------------
CVRES VIDCAPFUNC CVSaveImage( const char*       filename,
                              CVIMAGESTRUCT*    imageStructPtr,
                              BOOL              overwrite)
{
   if (imageStructPtr == 0)
   {
      return CVRES_INVALID_PARAMETER;
   }

   /// Check image data size in struct
   if (imageStructPtr->ImageDataSize != (imageStructPtr->ImageWidth * 
                                         imageStructPtr->ImageHeight * 
                                         imageStructPtr->BytesPerPixel))
   {
      /// Invalid image size...
      return CVRES_DLL_VIDCAP_INVALID_IMAGE_STRUCT;
   }

   /// Create a CVImage to contain the passed in image for saving...
   CVImage* saveImage = 0;   
   CVRES result = CVImage::CreateImage(
                     (CVImage::CVIMAGE_TYPE)imageStructPtr->ImageType,
                     saveImage,
                     imageStructPtr->ImageWidth,
                     imageStructPtr->ImageHeight,
                     false);
   
   if (CVFAILED(result))
   {
      return result;
   }

   /// Double check bytes per pixel before performing copy
   if (imageStructPtr->BytesPerPixel != saveImage->GetBytesPerPixel())
   {
      CVImage::ReleaseImage(saveImage);
      return CVRES_DLL_VIDCAP_INVALID_IMAGE_STRUCT;
   }

   /// Copy data into CVImage
   memcpy(  saveImage->GetRawDataPtr(), 
            imageStructPtr->PixelDataPtr,
            imageStructPtr->ImageDataSize);
   
   /// Save it, free up the CVImage, and exit
   result = CVImage::Save(filename,saveImage,overwrite?true:false);
   CVImage::ReleaseImage(saveImage);
   
   return result;
}


//-------------------------------------------------------------------------
/// CVReleaseImage() releases an image retrieved from CVDevGrabImage()
/// and CVLoadImage().
///
/// \param imageStructPtr - pointer to image struct to release
//-------------------------------------------------------------------------
void VIDCAPFUNC CVReleaseImage( CVIMAGESTRUCT* imageStructPtr)
{
   if (imageStructPtr == 0)
   {
      return;
   }
   if (imageStructPtr->PixelDataPtr != 0)
   {
      delete [] imageStructPtr->PixelDataPtr;
   }
   delete imageStructPtr;
}

//-------------------------------------------------------------------------
/// CVGetVidCapString() retrieves the library identifier/copyright string.
/// \param buffer - buffer to receive capture string
/// \param bufLength - ptr to size of buffer. Set to length of string on return.
//-------------------------------------------------------------------------
void VIDCAPFUNC CVGetVidCapString( char* buffer, int* bufLength)
{
   if (bufLength == 0)
      return;

   if (buffer == 0)
   {
      *bufLength = strlen(kVIDCAPTURE_STRING);
      return;
   }

   strncpy(buffer, kVIDCAPTURE_STRING, *bufLength); 
   *bufLength = strlen(kVIDCAPTURE_STRING);
}

//-------------------------------------------------------------------------
/// CVImgStructFromImage() is an internal function to convert from a
/// CVImage* to a CVIMAGESTRUCT*.
///
/// You must call CVReleaseImage() on the created CVIMAGESTRUCT* when
/// done.
///
/// \param imageStructPtrPtr - ptr to receive a ptr to created image struct.
///        Call CVReleaseImage() on the returned image struct ptr when done.
/// \param image - image class object to convert
/// \return CVRES - CVRES_SUCCESS on success
//-------------------------------------------------------------------------
CVRES CVImgStructFromImage( CVIMAGESTRUCT**  imageStructPtrPtr, 
                            CVImage*         image)
{
   if (imageStructPtrPtr == 0)
   {
      return CVRES_INVALID_PARAMETER;
   }

   *imageStructPtrPtr = new CVIMAGESTRUCT;
   if (*imageStructPtrPtr == 0)
   {
      return CVRES_OUT_OF_MEMORY;
   }

   CVIMAGESTRUCT* imgStruct = *imageStructPtrPtr;

   imgStruct->Version         = kCVIMAGESTRUCTVER;   
   imgStruct->ImageType       = (CVIMAGETYPE)image->GetImageType();
   imgStruct->BytesPerPixel   = image->GetBytesPerPixel();
   imgStruct->NumChannels     = image->GetNumChannels();   
   imgStruct->ImageHeight     = image->Height();
   imgStruct->ImageWidth      = image->Width();
   
   imgStruct->ImageDataSize   = imgStruct->ImageWidth * 
                                imgStruct->ImageHeight * 
                                imgStruct->BytesPerPixel;

   imgStruct->PixelDataPtr    = new unsigned char[imgStruct->ImageDataSize];
   
   /// Bail if we couldn't allocate pixel data
   if (imgStruct->PixelDataPtr == 0)
   {
      delete *imageStructPtrPtr;
      *imageStructPtrPtr = 0;
      return CVRES_OUT_OF_MEMORY;
   }
   
   /// Copy image
   memcpy(  imgStruct->PixelDataPtr, 
            image->GetRawDataPtr(), 
            imgStruct->ImageDataSize);

   return CVRES_SUCCESS;
}

//-------------------------------------------------------------------------
/// CVDevGetProperty() retrieves the current, minimum, and maximum values
/// for the specified property.
///
/// If the property is not supported by the camera, then it will return
/// CVRES_DLL_VIDCAP_UNSUPPORTED_PROPERTY.
///
/// \param capSystem - handle to *connected* capture system.
/// \param property - property identifier
/// \param curValue   - ptr to receive current value of property.
/// \param defValue   - ptr to receive default value of property.
/// \param minValue   - ptr to receive minimum value of property.
/// \param maxValue   - ptr to receive maximum value of property.
/// \param step       - ptr to receive the minimum step distance
///                     between values.            
/// \sa CVDevSetProperty()
CVRES VIDCAPFUNC CVDevGetProperty(  CVVIDCAPSYSTEM capSystem, 
                                    CVCAMERAPROP   property,
                                    long*           curValue, 
                                    long*           defValue,
                                    long*           minValue, 
                                    long*           maxValue,
                                    long*           step)
{
   CVAssert(capSystem != 0, "Invalid video capture handle");
   if (capSystem == 0)
   {
      return CVRES_DLL_VIDCAP_INVALID_HANDLE;
   }   
  
   CVVidCapture* vidCap = (CVVidCapture*)capSystem;
   
   CVVidCapture::CAMERA_PROPERTY camProp;
   
   /// This is a bit fugly, but I want to allow the class values to
   /// change while the DLL Values can't.  Also, some properties
   /// probably shouldn't be messed with by the DLL (e.g. COLOR).
   ///
   /// And, we've got the added bonus that bad values can be
   /// detected here...
   switch (property)
   {
      case CVCAM_BRIGHT:
         camProp = CVVidCapture::CAMERAPROP_BRIGHT;
         break;

      case CVCAM_CONTRAST:
         camProp = CVVidCapture::CAMERAPROP_CONTRAST;
         break;

      case CVCAM_HUE:
         camProp = CVVidCapture::CAMERAPROP_HUE;
         break;

      case CVCAM_SAT:
         camProp = CVVidCapture::CAMERAPROP_SAT;
         break;

      case CVCAM_SHARP:
         camProp = CVVidCapture::CAMERAPROP_SHARP;
         break;

      case CVCAM_GAMMA:
         camProp = CVVidCapture::CAMERAPROP_GAMMA;
         break;

      case CVCAM_WHITEBALANCE:
         camProp = CVVidCapture::CAMERAPROP_WHITEBALANCE;
         break;

      case CVCAM_GAIN:
         camProp = CVVidCapture::CAMERAPROP_GAIN;
         break;
      
      default:
         return CVRES_INVALID_PARAMETER;
   }
   
   
   return vidCap->GetPropertyInfo(camProp, 
                                  curValue,
                                  defValue,
                                  minValue,
                                  maxValue,
                                  step);
}

//-------------------------------------------------------------------------
/// CVDevSetProperty() sets the specified property value for the camera.
///
/// If the property is not supported by the camera, then it will return
/// CVRES_DLL_VIDCAP_UNSUPPORTED_PROPERTY.
/// 
/// \param capSystem - handle to *connected* capture system.
/// \param property  - property identifier
/// \param newValue  - new value for the property. 
///                    Should be within range given by CVGetProperty()
///
/// \sa CVDevGetProperty()
//-------------------------------------------------------------------------
CVRES VIDCAPFUNC CVDevSetProperty(  CVVIDCAPSYSTEM capSystem,
                                    CVCAMERAPROP   property,
                                    long newValue)
{
   CVAssert(capSystem != 0, "Invalid video capture handle");
   if (capSystem == 0)
   {
      return CVRES_DLL_VIDCAP_INVALID_HANDLE;
   }   
  
   CVVidCapture* vidCap = (CVVidCapture*)capSystem;
   
   CVVidCapture::CAMERA_PROPERTY camProp;
   
   /// This is a bit fugly, but I want to allow the class values to
   /// change while the DLL Values can't.  Also, some properties
   /// probably shouldn't be messed with by the DLL (e.g. COLOR).
   ///
   /// And, we've got the added bonus that bad values can be
   /// detected here...
   switch (property)
   {
      case CVCAM_BRIGHT:
         camProp = CVVidCapture::CAMERAPROP_BRIGHT;
         break;

      case CVCAM_CONTRAST:
         camProp = CVVidCapture::CAMERAPROP_CONTRAST;
         break;

      case CVCAM_HUE:
         camProp = CVVidCapture::CAMERAPROP_HUE;
         break;

      case CVCAM_SAT:
         camProp = CVVidCapture::CAMERAPROP_SAT;
         break;

      case CVCAM_SHARP:
         camProp = CVVidCapture::CAMERAPROP_SHARP;
         break;

      case CVCAM_GAMMA:
         camProp = CVVidCapture::CAMERAPROP_GAMMA;
         break;

      case CVCAM_WHITEBALANCE:
         camProp = CVVidCapture::CAMERAPROP_WHITEBALANCE;
         break;

      case CVCAM_GAIN:
         camProp = CVVidCapture::CAMERAPROP_GAIN;
         break;
      
      default:
         return CVRES_INVALID_PARAMETER;
   }

   return vidCap->SetProperty(camProp, newValue);
}
