/*
// VidCapDll.h
// Interface for C-style DLL wrapper for VidCapture library
// Written by Michael Ellison
//-------------------------------------------------------------------------
//                      CodeVis's Free License
//                         www.codevis.com
//
// Copyright (c) 2004 by Michael Ellison (mike@codevis.com)
// All rights reserved.
//
// You may use this software in source and/or binary form, with or without
// modification, for commercial or non-commercial purposes, provided that 
// you comply with the following conditions:
//
// * Redistributions of source code must retain the above copyright notice,
//   this list of conditions and the following disclaimer. 
//
// * Redistributions of modified source must be clearly marked as modified,
//   and due notice must be placed in the modified source indicating the
//   type of modification(s) and the name(s) of the person(s) performing
//   said modification(s).
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
// LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//---------------------------------------------------------------------------
// Modifications:
//
//---------------------------------------------------------------------------
  * \file VidCapDll.h
  * \brief Interface for C-style DLL wrapper for VidCapture library
  *
  * This file is designed to be included in both the DLL project and any
  * client projects that wish to use the .DLL.
  *
  * VIDCAPDLL_EXPORTS must be defined in the .DLL project, and must *not*
  * be defined in clients.
  *
  * $RCSfile: VidCapDll.h,v $
  * $Date: 2004/03/01 16:28:15 $
  * $Revision: 1.3 $
  * $Author: mikeellison $
*/
#ifndef _VIDCAPDLL_H_
#define _VIDCAPDLL_H_

#include "CVRes.h"
#include "CVImageStructs.h"

/* If being used as a client, also include the individual result code files.*/
#ifndef VIDCAPDLL_EXPORTS   
   #include "CVResFile.h"
   #include "CVResImage.h"
   #include "CVResVidCap.h"
   #include "CVResDll.h"
#endif


/* Define function types as WINAPI calls w/DLL import/export rules */
#ifdef VIDCAPDLL_EXPORTS
   #define VIDCAPFUNC _declspec(dllexport) WINAPI
#else   
   #define VIDCAPFUNC _declspec(dllimport) WINAPI      
#endif


/* Prevent symbol decoration */
#ifdef __cplusplus
extern "C"
{
#endif

/*
  * Declare a handle for the CVVidCapture class as a void* so we
  * can use it as an opaque handle in a c-style interface.
  *
  * This allows us to provide a consistent interface across languages that,
  * while 'object oriented', doesn't require that the language support C++
  * class exportation through libraries.
*/
typedef void* CVVIDCAPSYSTEM;

/*
  * Similar to CVVIDCAPSYSTEM, this handle is used to track information during
  * a capture run.  It must be passed when calling Stop() on the
  * capture.
*/
typedef void* CVCAPHANDLE;

/*
  * CVVIDCAPDLLCB is the callback used for image capture operations.
  * It is analogous to CVVidCapture::CVVIDCAP_CALLBACK, except that
  * a structure is used to hold the image.
*/
typedef BOOL (WINAPI* CVVIDCAPDLLCB)( 
                        CVRES                   status,
                        struct CVIMAGESTRUCT*   imagePtr,
                        void*                   userParam   );

/*
  * CVAcquireVidCap() acquires a video capture object and initializes it.
  * You must call CVReleaseVidCap() when done with the handle returned
  * on a successful call.
  *
  * \param vidCapSystem - ptr to handle. Contains new handle on success.
  * \return CVRES - CVRES_SUCCESS on successful initialization.
  *
  * \sa CVReleaseVidCap()
*/
CVRES   VIDCAPFUNC CVAcquireVidCap( CVVIDCAPSYSTEM* vidCapSystem);

/*
  * CVReleaseVidCap() releases a previously allocated video capture object.
  *
  * \param vidCapSystem - Handle from CVAcquireVidCap(). 
  *
  * \return CVRES - CVRES_SUCCESS on success.
  * \sa CVAcquireVidCap()
*/
CVRES   VIDCAPFUNC CVReleaseVidCap( CVVIDCAPSYSTEM vidCapSystem);

/*
  * CVGetNumDevices() retrieves the number of capture devices
  * available to the VidCap .DLL.
  *
  * \param vidCapSystem - handle from CVAcquireVidCap()
  * \return int - number of available capture devices.
*/
int     VIDCAPFUNC CVGetNumDevices( CVVIDCAPSYSTEM vidCapSystem);

/*
  * CVGetDeviceName() retrieves the name of a capture device
  * into the provided buffer.
  *
  * \param vidCapSystem  - handle from CVAcquireVidCap()
  * \param deviceNum     - index of device (0 -> CVGetNumDevices() - 1)
  * \param devNameBuffer - buffer to receive ASCIIZ device name.
  *                        must be allocated by caller!
  * \param nameBufLen    - ptr to Maximum length of devNameBuffer.
  *                        set to length of device name on return.
  *
  * \return CVRES - CVRES_SUCCESS on success.
  * \sa CVGetNumDevices(), CVDevConnect()
*/
CVRES   VIDCAPFUNC CVGetDeviceName( CVVIDCAPSYSTEM vidCapSystem,
                                    int          deviceNum,
                                    char*        devNameBuffer,
                                    int*         nameBufLen);

/*
  * CVDevConnect() connects to the specified device.
  * Only one device should be connected at a time.
  *
  * Call CVDevDisconnect() to disconnect.
  *
  * \param vidCapSystem - handle from CVAcquireVidCap()
  * \param devIndex - index of device to connect to
  * \return CVRES - CVRES_SUCCESS on success
  * \sa CVDevDisconnect(), CVGetDeviceName(), CVAcquireVidCap()
*/
CVRES   VIDCAPFUNC CVDevConnect   ( CVVIDCAPSYSTEM vidCapSystem,
                                    int            devIndex);

/*
  * CVDevDisconnect() disconnects a previously connected device.
  * CVDevDisconnect() should be called when done with a capture
  * device connected via CVDevConnect().
  *
  * \param vidCapSystem - handle from CVAcquireVidCap()
  * \return CVRES - CVRES_SUCCESS on success
  * \sa CVDevCOnnect()
*/
CVRES   VIDCAPFUNC CVDevDisconnect( CVVIDCAPSYSTEM vidCapSystem );

/*
  * CVDevGetNumModes() retrieves the number of available mode
  * on a connected capture device.
  *
  * You *must* connect to a device before you can retrieve the
  * available modes for it. If you do not, you'll just get
  * 0 for the number of modes.
  *
  * \param vidCapSystem - handle from CVAcquireVidCap()   
  * \return int - number of modes available for the connected device
*/
int     VIDCAPFUNC CVDevGetNumModes( CVVIDCAPSYSTEM vidCapSystem );                                        

/*
  * CVDevGetModeInfo() retrieve information about the specified
  * mode.
  *
  * \param vidCapSystem - handle from CVAcquireVidCap()
  * \param modeIndex - index of mode to use for capture
  * \param xRes - ptr to receive x resolution of the camera mode (required)
  * \param yRes - ptr to receive y resolution of the camera mode (required)  
  * \param frameRate - ptr to receive estimated framerate (may be null)
  * \param vidFormat - ptr to receive input video mode value (VIDCAP_FORMAT)
  *                    may be null.
  * \return CVRES - CVRES_SUCCESS on success
  * \sa CVDevGetNumModes(), CVDevCOnnect(), 
*/
CVRES   VIDCAPFUNC CVDevGetModeInfo( CVVIDCAPSYSTEM vidCapSystem,
                                     int          modeIndex,
                                     int*         xRes,
                                     int*         yRes,
                                     int*         frameRate,
                                     int*         vidFormat);


/*
  * CVDevGetFormatName() retrieves the name of the video format
  * for a camera mode.
  *
  * \param vidCapSystem - handle from CVAcquireVidCap()
  * \param vidFormat - video format type (from CVDevGetModeInfo)
  * \param vidFormatNameBuf - ptr to buffer to receive format name
  * \param vidFormatBufLen - ptr to length of buffer. set to length of
  *                          name on return.
  * \return CVRES - CVRES_SUCCESS on success
  * \sa CVDevGetModeInfo()
*/
CVRES VIDCAPFUNC CVDevGetFormatName( CVVIDCAPSYSTEM vidCapSystem,
                                     int            vidFormat,
                                     char*          vidFormatNameBuf,
                                     int*           vidFormatBufLen);


/*
  * CVDevGrabImage() grabs a single image from a selected and
  * connected camera.
  *
  * You must free the returned pointer when done by calling
  * CVReleaseImage() on it or you will leak massive amounts of
  * memory.
  *
  * \param vidCapSystem - handle from CVAcquireVidCap()
  * \param modeIndex - index of mode to use for capture
  * \param imageStructPtrPtr - ptr to receive a ptr to created image struct.
  *        Call CVReleaseImage() on the returned image struct ptr when done.
  * \return CVRES - CVRES_SUCCESS on success
  * \sa CVDevGetModeInfo()
*/
CVRES   VIDCAPFUNC CVDevGrabImage(   CVVIDCAPSYSTEM           vidCapSystem,
                                     int                    modeIndex,
                                     CVIMAGETYPE            imageType,
                                     struct CVIMAGESTRUCT** imageStructPtrPtr);
/*
  * CVDevStartCap() starts a continuous capture, sending each
  * image to the specified callback.
  *
  * The CVIMAGESTRUCT* passed to the callback is *only* valid
  * during the callback!  You must copy the data out if you'll
  * need it later.  However, you should NOT call
  * CVReleaseImage() on it - the DLL will do that for you
  * when your callback function returns.
  *
  * CVDevStartCap() also returns a handle in capHandlePtr -
  * you must pass this to CVDevStopCap() when you are done
  * capturing, even if the capture is stopped prematurely
  * by an error or through returning false in the callback.
  *
  * \param vidCapSystem - handle from CVAcquireVidCap()
  * \param modeIndex - index of mode to use for capture
  * \param imageType - type of image to capture
  * \param callback - callback to receive images during capture
  * \param cbUserParam - user parameter to send to callback
  * \param capHandlePtr - ptr to receive capture handle.
  * \return CVRES - CVRES_SUCCESS on success
*/
CVRES   VIDCAPFUNC CVDevStartCap(    CVVIDCAPSYSTEM  vidCapSystem,
                                     int           modeIndex,
                                     CVIMAGETYPE   imageType,
                                     CVVIDCAPDLLCB callback,
                                     void*         cbUserParm,
                                     CVCAPHANDLE*  capHandlePtr);

/*
  * CVDevStopCap() halts an image capture session started
  * by CVDevStartCap().
  *
  * This must be called for cleanup even if the capture is stopped 
  * prematurely by an error or by returning false from
  * within the callback function.
  *
  * \param vidCapSystem - vidcap handle from CVAcquireVidCap()   
  * \param capHandle - cap handle received from CVDevStartCap()
*/
CVRES   VIDCAPFUNC CVDevStopCap(     CVVIDCAPSYSTEM vidCapSystem,
                                     CVCAPHANDLE capHandle );

/*
  * CVLoadImage() loads an image from the specified .ppm/.pgm file.
  *
  * You must release it with CVReleaseImage() when done.
  *
  * \param filename - pointer to ASCIIZ filename of .ppm/.pgm file.
  * \param imageStructPtrPtr - ptr to receive a ptr to created image struct.
  *        Call CVReleaseImage() on the returned image struct ptr when done.
  * \sa CVReleaseImage(), CVSaveImage()
*/
CVRES VIDCAPFUNC CVLoadImage( const char*              filename,
                              struct CVIMAGESTRUCT**   imageStructPtrPtr);

/*
  * CVSaveImage() saves an image from a CVIMAGESTRUCT* to disk.
  *
  * \param filename - pointer to ASCIIZ filename of .ppm/.pgm file.
  * \param imageStructPtr - ptr to image struct
  * \param overwrite - TRUE to overwrite existing files, FALSE otherwise.
  * \sa CVLoadImage()
*/
CVRES VIDCAPFUNC CVSaveImage( const char*              filename,
                              struct CVIMAGESTRUCT*    imageStructPtr,
                              BOOL                     overwrite);
/*
  * CVReleaseImage() releases an image retrieved from CVDevGrabImage()
  * and CVLoadImage().
  *
  * \param imageStructPtr - pointer to image struct to release
*/
void VIDCAPFUNC CVReleaseImage( struct CVIMAGESTRUCT* imageStructPtr);

/*
  * CVGetVidCapString() retrieves the library identifier/copyright string.
  * \param buffer - buffer to receive capture string
  * \param bufLength - ptr to size of buffer. Set to length of string on return.
*/
void VIDCAPFUNC CVGetVidCapString( char* buffer, int* bufLength);

/*
  * CVCAMERAPROP defines the camera properties that may be available from
  * the VidCapDll if the camera supports them.  These are used
  * with CVDevGetProperty and CVDevSetProperty.
  *
  * Some or all of the properties may be unavailable on some cameras.
*/
#ifndef __cplusplus
   typedef int CVCAMERAPROP;
   enum
#else
   enum CVCAMERAPROP
#endif
{
   CVCAM_BRIGHT,           /* Brightness    */
   CVCAM_CONTRAST,         /* Contrast      */
   CVCAM_HUE,              /* Hue           */
   CVCAM_SAT,              /* Saturation    */
   CVCAM_SHARP,            /* Sharpness     */
   CVCAM_GAMMA,            /* Gamma         */
   CVCAM_WHITEBALANCE,     /* White Balance */
   CVCAM_GAIN,             /* Gain          */
   CVCAMERAPROP_LAST
};

/*
  * CVDevGetProperty() retrieves the current, minimum, and maximum values
  * for the specified property.
  *
  * If the property is not supported by the camera, then it will return
  * CVRES_DLL_VIDCAP_UNSUPPORTED_PROPERTY.
  *
  * You must call CVDevConnect() prior to calling this function.
  * 
  * \param capSystem - handle to *connected* capture system.
  * \param property - property identifier
  * \param curValue   - ptr to receive current value of property.
  * \param defValue   - ptr to receive default value of property.
  * \param minValue   - ptr to receive minimum value of property.
  * \param maxValue   - ptr to receive maximum value of property.
  * \param step       - ptr to receive the minimum step distance
  *                     between values.            
  * \sa CVDevSetProperty()
*/
CVRES VIDCAPFUNC CVDevGetProperty(  CVVIDCAPSYSTEM capSystem, 
                                    CVCAMERAPROP   property,
                                    long*           curValue, 
                                    long*           defValue,
                                    long*           minValue, 
                                    long*           maxValue,
                                    long*           step);

/*
  * CVDevSetProperty() sets the specified property value for the camera.
  *
  * If the property is not supported by the camera, then it will return
  * CVRES_DLL_VIDCAP_UNSUPPORTED_PROPERTY.
  * 
  * \param capSystem - handle to *connected* capture system.
  * \param property  - property identifier
  * \param newValue  - new value for the property. 
  *                    Should be within range given by CVGetProperty()
  *
  * \sa CVDevGetProperty()
*/
CVRES VIDCAPFUNC CVDevSetProperty(  CVVIDCAPSYSTEM capSystem,
                                    CVCAMERAPROP   property,
                                    long newValue);


/* End extern "C" guarding */
#ifdef __cplusplus
}
#endif

#endif /* _VIDCAPDLL_H_ */
