// Copyright 2019 Lassi Kortela
// SPDX-License-Identifier: ISC

#pragma once

#ifdef __cplusplus
extern "C" {
#endif

int shm_open_anon(void);

#ifdef __cplusplus
}
#endif
