# fxload-libusb

This files are part of libusb examples.
It is needed to load fx3 firmwares, required by some cameras (newer QHY, for instance).

https://github.com/libusb/libusb/tree/master/examples

To keep the files in sync with the original libusb examples, a shell script is provided: `get_sources.sh`.
