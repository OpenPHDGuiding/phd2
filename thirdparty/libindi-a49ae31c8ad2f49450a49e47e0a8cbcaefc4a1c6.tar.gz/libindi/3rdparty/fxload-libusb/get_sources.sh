#!/bin/bash
wget https://raw.githubusercontent.com/libusb/libusb/master/examples/ezusb.c
wget https://raw.githubusercontent.com/libusb/libusb/master/examples/ezusb.h
wget https://raw.githubusercontent.com/libusb/libusb/master/examples/fxload.c


