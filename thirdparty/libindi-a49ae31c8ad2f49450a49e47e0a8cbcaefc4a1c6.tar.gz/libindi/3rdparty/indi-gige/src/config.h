/* Define to 1 if you have the <linux/videodev2.h> header file. */
/* #undef HAVE_LINUX_VIDEODEV2_H */

/* The symbol timezone is an int, not a function */
#define TIMEZONE_IS_INT 1

/* Define if you have termios.h */
/* #undef HAVE_TERMIOS_H */

/* Define if you have fitsio.h */
/* #undef HAVE_CFITSIO_H */

/* Define if you have libnova.h */
/* #undef HAVE_NOVA_H */
