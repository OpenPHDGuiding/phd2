/*
 ASI Filter Wheel INDI Driver

 Copyright (c) Rumen G.Bogdanovski
 All Rights Reserved.

 This program is free software; you can redistribute it and/or modify it
 under the terms of the GNU General Public License as published by the Free
 Software Foundation; either version 2 of the License, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 more details.

 You should have received a copy of the GNU General Public License along with
 this program; if not, write to the Free Software Foundation, Inc., 59
 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

 The full GNU General Public License is included in this distribution in the
 file called LICENSE.
 */

#pragma once

#include "EFW_filter.h"

#include <indifilterwheel.h>

class ASIWHEEL : public INDI::FilterWheel
{
  private:
    int fw_id;

  public:
    ASIWHEEL(int id, EFW_INFO info, bool enumerate);
    ~ASIWHEEL();

    virtual void debugTriggered(bool enable) override;
    virtual void simulationTriggered(bool enable) override;

    virtual bool Connect() override;
    virtual bool Disconnect() override;
    virtual const char *getDefaultName() override;

    virtual bool initProperties() override;

    virtual void ISGetProperties(const char *dev) override;

    virtual int QueryFilter() override;
    virtual bool SelectFilter(int) override;
    virtual void TimerHit() override;
    virtual bool SetFilterNames() override { return true; }
    virtual bool GetFilterNames(const char *) override;

    char name[100];
};
