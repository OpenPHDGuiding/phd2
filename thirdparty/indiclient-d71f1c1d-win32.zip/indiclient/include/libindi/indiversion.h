/* Set INDI Library version */
#define INDI_VERSION 1.4.1

/* Define INDI Data Dir */
#define DATA_INSTALL_DIR "C:/cygwin/home/agalasso/Incoming/tmp/indiclient/share/indi/"
