/* Set INDI Library version */
#define INDI_VERSION 1.7.2

/* Define INDI Data Dir */
#define DATA_INSTALL_DIR "C:/cygwin/home/agalasso/Incoming/indiclient/share/indi/"
