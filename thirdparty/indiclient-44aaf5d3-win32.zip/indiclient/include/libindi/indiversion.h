/* Set INDI Library version */
#define INDI_VERSION 1.7.2

/* Define INDI Data Dir */
#define DATA_INSTALL_DIR "../indiclient/share/indi/"
